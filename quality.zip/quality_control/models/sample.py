# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from math import sqrt
from dateutil.relativedelta import relativedelta
from datetime import datetime
import random

from odoo import api, models, fields, _, SUPERUSER_ID
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError

class QualityCheckSample(models.Model):
    _name = "qc.sample"
    _description = "Sampling"
    # _inherit = ['mail.thread']
    _rec_name = "title"


    title = fields.Char()
    # order_qty = fields.Integer()
    order_no = fields.Char()
    partner_id = fields.Many2one('res.partner',string="Customer")
    product_id = fields.Many2one('product.product',string="Product Name")
    is_revised = fields.Boolean(copy=False)

    @api.onchange('order_no','is_revised')
    def onchange_order_no(self):
        # list = self.env['qc.sample'].search([('order_no', '=', self.order_no.id)]).mapped("revisions")
        # last_revisoion = max(list(map(int, list.revision)))
        # dict(self._fields['revisions'].selection).get(list.revisions)
        list = self.env['qc.sample'].search([('order_no', '=', self.order_no.id)],limit=1, order="create_date desc")
        self.sample_id = list.id
        if int(self.sample_id.revisions) != 5:
            self.revisions = str(int(self.sample_id.revisions) +1)
        domain = {'sample_id': [('id', '=', list.id)]}
        return {'domain': domain}


    sample_id = fields.Many2one('qc.sample',copy=False)
    order_quantity = fields.Float(copy=False)

    button_setup_id = fields.Many2one('buttons.setup',copy=False)
    revisions = fields.Selection([('1', '1st Revision'),
                                  ('2', '2nd Revision'),
                                  ('3', '3rd Revision'),
                                  ('4', '4th Revision'),
                                  ('5', '5th Revision')], default=False,copy=False)
    state = fields.Selection([('needs_revision','Needs Revision'),('approve','Approve')],default= False,copy=False)

    revision_reason = fields.Text(copy=False)

    requested_by = fields.Many2one('res.users','Revision Request',copy=False)

    def action_approve_sample(self):
        self.state = 'approve'



    q2pri = fields.Boolean(related='button_setup_id.q2pri')
    q2cut = fields.Boolean(related='button_setup_id.q2cut')
    q2emb = fields.Boolean(related='button_setup_id.q2emb')
    q2mar = fields.Boolean(related='button_setup_id.q2mar')
    q2lay = fields.Boolean(related='button_setup_id.q2lay')
    q2fus = fields.Boolean(related='button_setup_id.q2fus')
    # QC 3 Buttons
    q3new = fields.Boolean(related='button_setup_id.q3new')
    q3inl = fields.Boolean(related='button_setup_id.q3inl')
    q3aud = fields.Boolean(related='button_setup_id.q3aud')
    q3dai = fields.Boolean(related='button_setup_id.q3dai')
    q3ful = fields.Boolean(related='button_setup_id.q3ful')
    # QC 4 Buttons
    q4dry = fields.Boolean(related='button_setup_id.q4dry')
    q4wet = fields.Boolean(related='button_setup_id.q4wet')
    # QC 5 Buttons
    q5but = fields.Boolean(related='button_setup_id.q5but')
    q5lab = fields.Boolean(related='button_setup_id.q5lab')
    q5pul = fields.Boolean(related='button_setup_id.q5pul')

    # QC 6 Buttons
    q6acc = fields.Boolean(related='button_setup_id.q6acc')
    q6dai = fields.Boolean(related='button_setup_id.q6dai')
    q6ful = fields.Boolean(related='button_setup_id.q6ful')
    q6men = fields.Boolean(related='button_setup_id.q6men')

    # QC final
    qfinal = fields.Boolean(related='button_setup_id.qfinal')

    qcp_type = fields.Selection([
        # ('qc1', 'Quality Check 1'),
        ('qc2', 'Cutting QC'),
        ('qc3', 'Stitching QC'),
        ('qc4', 'Washing QC'),
        ('qc5', 'Pre Finishing QC'),
        ('qc6', 'Finishing QC'),
        ('qc7', 'Final QC')], string="QCP Type", default='qc2',copy=False)


    sampling_inline_qc_count = fields.Float(compute="_compute_sampling_inline_qc_counts")
    sampling_button_and_rivets_qc_count = fields.Float(compute="_compute_sampling_button_and_rivets_qc_counts")
    sampling_label_section_report_qc_count = fields.Float(compute="_compute_sampling_label_section_report_qc_counts")
    sampling_pull_test_qc_count = fields.Float(compute="_compute_sampling_pull_test_qc_counts")
    sampling_accessories_inspection_qc_count = fields.Float(compute="compute_sampling_accessories_inspection_qc_counts")
    sampling_daily_major_quality_qc_count = fields.Float(compute="compute_sampling_daily_major_quality_qc_counts")
    sampling_full_body_measurement_report_qc_count = fields.Float(compute="compute_sampling_full_body_measurement_report_qc_counts")
    sampling_mending_qc_count = fields.Float(compute="compute_sampling_mending_qc_counts")
    sampling_final_qc_count = fields.Float(compute="compute_sampling_final_qc_counts")
    sampling_audit_report_count = fields.Float(compute="_compute_sampling_audit_report")
    sampling_daily_top_3_faults_count = fields.Float(compute="_compute_sampling_daily_top_3_faults")
    sampling_full_body_measurement_stitching_count = fields.Float(compute="_compute_sampling_full_body_measurement_stitching")
    sampling_printing_qc_count = fields.Float(compute="_compute_sampling_printing_qc_counts")
    sampling_cutting_inspection_qc_count = fields.Float(compute="_compute_sampling_cutting_inspection_qc_counts")
    sampling_embroidery_qc_count = fields.Float(compute="_compute_sampling_embroidery_qc_counts")
    sampling_marker_qc_count = fields.Float(compute="_compute_sampling_marker_qc_counts")
    sampling_lay_spreading_qc_count = fields.Float(compute="_compute_sampling_lay_spreading_qc_counts")
    sampling_fusing_qc_count = fields.Float(compute="_compute_sampling_fusing_qc_counts")
    sampling_dry_wash_qc_count = fields.Float(compute="_compute_sampling_dry_wash_qc_counts")
    sampling_wet_wash_qc_count = fields.Float(compute="_compute_sampling_wet_wash_qc_counts")
    sampling_new_order_qc_count = fields.Float(compute="_compute_sampling_new_order_qc_counts")


    # QC:2

    def _compute_sampling_printing_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_printing')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_printing_qc_count = result.get(sample.id, 0)

    def _compute_sampling_cutting_inspection_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_cutting_inspection')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_cutting_inspection_qc_count = result.get(sample.id, 0)

    def _compute_sampling_embroidery_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_embroidery')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_embroidery_qc_count = result.get(sample.id, 0)

    def _compute_sampling_marker_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_marker')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_marker_qc_count = result.get(sample.id, 0)

    def _compute_sampling_lay_spreading_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_lay_spreading')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_lay_spreading_qc_count = result.get(sample.id, 0)

    def _compute_sampling_fusing_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_fusing')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_fusing_qc_count = result.get(sample.id, 0)


# QC:3

    def _compute_sampling_new_order_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_new_order')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_new_order_qc_count = result.get(sample.id, 0)


    def _compute_sampling_audit_report(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_audit_report')],
            ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_audit_report_count = result.get(sample.id, 0)

    def _compute_sampling_daily_top_3_faults(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_daily_top_3_faults')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_daily_top_3_faults_count = result.get(sample.id, 0)

    def _compute_sampling_full_body_measurement_stitching(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_full_body_measurement_stitching')], ['sample_id'],
            ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_full_body_measurement_stitching_count = result.get(sample.id, 0)

    # QC:3
    def _compute_sampling_inline_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_inline')],
            ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_inline_qc_count = result.get(sample.id, 0)


#QC: 4
    def _compute_sampling_button_and_rivets_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_button_and_rivets')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_button_and_rivets_qc_count = result.get(sample.id, 0)

    def _compute_sampling_label_section_report_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_label_section_report')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_label_section_report_qc_count = result.get(sample.id, 0)

    def _compute_sampling_pull_test_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('sample_id', 'in', self.ids), ('type', '=', 'sampling_pull_test')],
                                                          ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_pull_test_qc_count = result.get(sample.id, 0)




# QC:5
    def compute_sampling_accessories_inspection_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_accessories_inspection')], ['sample_id'],
            ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_accessories_inspection_qc_count = result.get(sample.id, 0)

    def compute_sampling_daily_major_quality_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_daily_major_quality')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_daily_major_quality_qc_count = result.get(sample.id, 0)

    def compute_sampling_full_body_measurement_report_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_full_body_measurement_report')], ['sample_id'],
            ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_full_body_measurement_report_qc_count = result.get(sample.id, 0)

    def compute_sampling_mending_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_mending')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_mending_qc_count = result.get(sample.id, 0)

# QC:6
    def _compute_sampling_dry_wash_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_dry_wash')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_dry_wash_qc_count = result.get(sample.id, 0)

    def _compute_sampling_wet_wash_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_wet_wash')], ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_wet_wash_qc_count = result.get(sample.id, 0)


#QC : 7
    def compute_sampling_final_qc_counts(self):
        check_data = self.env['quality.check'].read_group(
            [('sample_id', 'in', self.ids), ('type', '=', 'sampling_final_qc')],
            ['sample_id'], ['sample_id'])
        result = dict((data['sample_id'][0], data['sample_id_count']) for data in check_data)
        for sample in self:
            sample.sampling_final_qc_count = result.get(sample.id, 0)








    def action_sampling_button_and_rivets_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_button_and_rivets_extension').read()[0]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'button_and_rivets')]

        action['views'] = [(self.env.ref('quality_control.quality_check_button_and_rivets_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_button_and_rivets_view_form').id, 'form')]

        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_button_and_rivets',
            'default_sample_id': self.id
        }
        return action


    def action_sampling_label_section_report_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_label_section_report_extension').read()[0]
        # action['name'] = 'Label Section Report'
        # print("action.name",action['name'], "\n",action)
        # action['name'] = _('Label Section Report')
        action['name'] = 'Sampling Label Section Report'
        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_label_section_report')]

        action['views'] = [(self.env.ref('quality_control.quality_check_label_section_report_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_label_section_report_view_form').id, 'form')]

        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_label_section_report',
            'default_sample_id': self.id
        }
        return action


    def action_sampling_pull_test_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_pull_test_extension').read()[0]
        # action['name'] = 'Label Section Report'
        # print("action.name",action['name'], "\n",action)
        # action['name'] = _('Label Section Report')
        action['name'] = 'Sampling Pull Test'
        action['domain'] = [('sample_id', '=', self.id),('type','=','sampling_pull_test')]

        action['views'] = [(self.env.ref('quality_control.quality_check_pull_test_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_pull_test_view_form').id, 'form')]

        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_pull_test',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_accessories_inspection_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_accessories_inspection_extension').read()[0]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_accessories_inspection')]

        action['views'] = [(self.env.ref('quality_control.quality_check_accessories_inspection_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_accessories_inspection_view_form').id, 'form')]

        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_accessories_inspection',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_daily_major_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_daily_major_quality_extension').read()[0]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_daily_major_quality')]

        action['views'] = [(self.env.ref('quality_control.quality_check_daily_major_quality_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_daily_major_quality_view_form').id, 'form')]

        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_daily_major_quality',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_full_body_measurement_report_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_full_body_measurement_report_extension').read()[0]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_full_body_measurement_report')]

        action['views'] = [(self.env.ref('quality_control.quality_check_full_body_measurement_report_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_full_body_measurement_report_view_form').id, 'form')]

        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_full_body_measurement_report',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_mending_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_mending_extension').read()[0]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_mending')]

        action['views'] = [(self.env.ref('quality_control.quality_check_mending_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_mending_view_form').id, 'form')]

        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_mending',
            'default_sample_id': self.id
        }
        return action
#QC : 7
    def action_sampling_final_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_final_quality_checks_extension').read()[0]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_final_qc')]

        action['views'] = [(self.env.ref('quality_control.final_quality_checks_view_tree').id, 'tree')
            , (self.env.ref('quality_control.final_quality_checks_view_form').id, 'form')]

        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_final_qc',
            'default_sample_id': self.id
        }
        return action

#QC: 3
    def action_sampling_audit_report_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_audit_report_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_audit_report_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_audit_report_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_audit_report')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_audit_report',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_daily_top_3_faults_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_daily_top_3_faults_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_daily_top_3_faults_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_daily_top_3_faults_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'daily_top_3_faults')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_daily_top_3_faults',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_full_body_measurement_stitching_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_full_body_measurement_stitching_extension').read()[0]
        action['views'] = [
            (self.env.ref('quality_control.quality_check_full_body_measurement_stitching_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_full_body_measurement_stitching_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_full_body_measurement_stitching')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_full_body_measurement_stitching',
            'default_sample_id': self.id
        }
        return action

# QC: 2
    def action_sampling_printing_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_printing_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_printing_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_printing_check_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_printing')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_printing',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_cutting_inspection_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_cutting_extension').read()[
            0]
        action['views'] = [
            (self.env.ref('quality_control.quality_check_cutting_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_cutting_check_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_cutting_inspection')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_cutting_inspection',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_embroidery_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_embroidery_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_embroidery_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_embroidery_check_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_embroidery')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_embroidery',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_marker_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_marker_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_marker_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_marker_check_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_marker')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_marker',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_lay_spreading_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_lay_spreading_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_lay_spreading_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_lay_spreading_check_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_lay_spreading')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_lay_spreading',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_fusing_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_fusing_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_fusing_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_fusing_check_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_fusing')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_fusing',
            'default_sample_id': self.id
        }
        return action

#QC: 5
    def action_sampling_dry_wash_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.action_quality_check_dry_wash_qc_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_dry_wash_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_dry_wash_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_dry_wash')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_dry_wash',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_wet_wash_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.action_quality_check_wet_wash_qc_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_wet_wash_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_wet_wash_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_wet_wash')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_wet_wash',
            'default_sample_id': self.id
        }
        return action

#QC :3
    def action_sampling_new_order_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_new_order_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_new_order_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_new_order_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id), ('type', '=', 'sampling_new_order')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_new_order',
            'default_sample_id': self.id
        }
        return action

    def action_sampling_inline_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_inline_report_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_inline_report_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_inline_report_view_form').id, 'form')]

        action['domain'] = [('sample_id', '=', self.id),('type','=','sampling_inline')]
        action['context'] = {
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'sampling_inline',
            'default_sample_id': self.id
        }
        return action



    #Buttons

    def action_quality_check2(self):
        self.qcp_type = 'qc2'




    def action_quality_check3(self):
        qc2_dict = {}

        if self.q2pri == False:
            qc2_dict["printing"] = False
            if self.sampling_printing_qc_count > 0:
                qc2_dict["printing"] = True

        if self.q2cut == False:
            qc2_dict["cutting"] = False
            if self.sampling_cutting_inspection_qc_count > 0:
                qc2_dict["cutting"] = True

        if self.q2emb == False:
            qc2_dict["embroidery"] = False
            if self.sampling_embroidery_qc_count > 0:
                qc2_dict["embroidery"] = True

        if self.q2mar == False:
            qc2_dict["marker"] = False
            if self.sampling_marker_qc_count > 0:
                qc2_dict["marker"] = True

        if self.q2lay == False:
            qc2_dict["lay_spreading"] = False
            if self.sampling_lay_spreading_qc_count > 0:
                qc2_dict["lay_spreading"] = True

        if self.q2fus == False:
            qc2_dict["fusing"] = False
            if self.sampling_fusing_qc_count > 0:
                qc2_dict["fusing"] = True

        if False in qc2_dict.values():
            raise UserError(_("Please Complete Cutting QC First Before proceed to Stitching QC !!"))
        else:
            self.qcp_type = 'qc3'

    def action_quality_check4(self):
        qc3_dict = {}

        if self.q3new == False:
            qc3_dict["new_order"] = False
            if self.sampling_new_order_qc_count > 0:
                qc3_dict["new_order"] = True

        if self.q3inl == False:
            qc3_dict["inline_report"] = False
            if self.sampling_inline_qc_count > 0:
                qc3_dict["inline_report"] = True

        if self.q3aud == False:
            qc3_dict["audit_report"] = False
            if self.sampling_audit_report_count > 0:
                qc3_dict["audit_report"] = True

        if self.q3dai == False:
            qc3_dict["daily_top_3_faults"] = False
            if self.sampling_daily_top_3_faults_count > 0:
                qc3_dict["daily_top_3_faults"] = True

        if self.q3ful == False:
            qc3_dict["full_body_measurement_stitching"] = False
            if self.sampling_full_body_measurement_stitching_count > 0:
                qc3_dict["full_body_measurement_stitching"] = True
        print(qc3_dict)
        if False in qc3_dict.values():
            raise UserError(_("Please Complete Stitching QC First Before proceed to Washing QC !!"))
        else:
            self.qcp_type = 'qc4'

    def action_quality_check5(self):
        qc4_dict = {}

        if self.q4dry == False:
            qc4_dict["dry_wash"] = False
            if self.sampling_dry_wash_qc_count > 0:
                qc4_dict["dry_wash"] = True

        if self.q4wet == False:
            qc4_dict["wet_wash"] = False
            if self.sampling_wet_wash_qc_count > 0:
                qc4_dict["wet_wash"] = True

        if False in qc4_dict.values():
            raise UserError(_("Please Complete Washing QC First Before proceed to Pre Finishing QC !!"))
        else:
            self.qcp_type = 'qc5'

    def action_quality_check6(self):
        qc5_dict = {}
        if self.q5but == False:
            qc5_dict["button_and_rivets"] = False
            if self.sampling_button_and_rivets_qc_count > 0:
                qc5_dict["button_and_rivets"] = True

        if self.q5lab == False:
            qc5_dict["label_section_report"] = False
            if self.sampling_label_section_report_qc_count > 0:
                qc5_dict["label_section_report"] = True

        if self.q5pul == False:
            qc5_dict["pull_test"] = False
            if self.sampling_pull_test_qc_count > 0:
                qc5_dict["pull_test"] = True

        if False in qc5_dict.values():
            raise UserError(_("Please Complete Quality Pre Finishing QC First Before proceed to Finishing QC !!"))
        else:
            self.qcp_type = 'qc6'

    def action_quality_check7(self):
        qc6_dict = {}
        if self.q6acc == False:
            qc6_dict["accessories_inspection"] = False
            if self.sampling_accessories_inspection_qc_count > 0:
                qc6_dict["accessories_inspection"] = True

        if self.q6dai == False:
            qc6_dict["daily_major_quality"] = False
            if self.sampling_daily_major_quality_qc_count > 0:
                qc6_dict["daily_major_quality"] = True

        if self.q6ful == False:
            qc6_dict["full_body_measurement_report"] = False
            if self.sampling_full_body_measurement_report_qc_count > 0:
                qc6_dict["full_body_measurement_report"] = True

        if self.q6men == False:
            qc6_dict["mending"] = False
            if self.sampling_mending_qc_count > 0:
                qc6_dict["mending"] = True

        if False in qc6_dict.values():
            raise UserError(_("Please Complete Finishing QC First Before proceed to Final QC !!"))
        else:
            self.qcp_type = 'qc7'