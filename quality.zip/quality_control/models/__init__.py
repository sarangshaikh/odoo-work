# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import quality
from . import quality_control
from . import sample
from . import quality_check
from . import product
from . import stock_move
from . import stock_picking
from . import qc2_daily_washing_quality_check_report
