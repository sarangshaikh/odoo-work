# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from math import sqrt
from dateutil.relativedelta import relativedelta
from datetime import datetime
import random

from odoo import api, models, fields, _, SUPERUSER_ID
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError

class QualityPoint(models.Model):
    _inherit = "quality.point"

    failure_message = fields.Html('Failure Message')
    measure_frequency_type = fields.Selection([
        ('all', 'All Operations'),
        ('random', 'Randomly'),
        ('periodical', 'Periodically')], string="Type of Frequency",
        default='all', required=True)
    measure_frequency_value = fields.Float('Percentage')  # TDE RENAME ?
    measure_frequency_unit_value = fields.Integer('Frequency Unit Value')  # TDE RENAME ?
    measure_frequency_unit = fields.Selection([
        ('day', 'Days'),
        ('week', 'Weeks'),
        ('month', 'Months')], default="day")  # TDE RENAME ?
    norm = fields.Float('Norm', digits='Quality Tests')  # TDE RENAME ?
    tolerance_min = fields.Float('Min Tolerance', digits='Quality Tests')
    tolerance_max = fields.Float('Max Tolerance', digits='Quality Tests')
    norm_unit = fields.Char('Norm Unit', default=lambda self: 'mm')  # TDE RENAME ?
    average = fields.Float(compute="_compute_standard_deviation_and_average")
    standard_deviation = fields.Float(compute="_compute_standard_deviation_and_average")



# QC :2
    printing_qc_count = fields.Float(compute="_compute_printing_qc_counts")
    cutting_inspection_count = fields.Float(compute="_compute_cutting_inspection_counts")
    embroidery_qc_count = fields.Float(compute="_compute_embroidery_qc_counts")
    marker_qc_count = fields.Float(compute="_compute_marker_qc_counts")
    lay_spreading_qc_count = fields.Float(compute="_compute_lay_spreading_qc_counts")
    fusing_qc_count = fields.Float(compute="_compute_fusing_qc_counts")

# QC :3
    new_order_count = fields.Float(compute="_compute_new_order")
    inline_report_count = fields.Float(compute="_compute_inline_report")
    audit_report_count = fields.Float(compute="_compute_audit_report")
    daily_top_3_faults_count = fields.Float(compute="_compute_daily_top_3_faults")
    full_body_measurement_stitching_count = fields.Float(compute="_compute_full_body_measurement_stitching")

# QC :4
    dry_wash_qc_count = fields.Float(compute="_compute_dry_wash_qc_counts")
    wet_wash_qc_count = fields.Float(compute="_compute_wet_wash_qc_counts")

# QC :5
    button_and_rivets_qc_count = fields.Float(compute="_compute_button_and_rivets_qc_counts")
    label_section_report_qc_count = fields.Float(compute="_compute_label_section_report_qc_counts")
    pull_test_qc_count = fields.Float(compute="_compute_pull_test_qc_counts")

# QC :6
    accessories_inspection_qc_count = fields.Float(compute="compute_accessories_inspection_qc_counts")
    daily_major_quality_qc_count = fields.Float(compute="compute_daily_major_quality_qc_counts")

    full_body_measurement_report_qc_count = fields.Float(compute="compute_full_body_measurement_report_qc_counts")
    mending_qc_count = fields.Float(compute="compute_mending_qc_counts")

# QC :7
    final_qc_count = fields.Float(compute="compute_final_qc_counts")



# QC:2
    def _compute_printing_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','printing')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.printing_qc_count = result.get(point.id, 0)

    def _compute_cutting_inspection_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','cutting')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.cutting_inspection_count = result.get(point.id, 0)

    def _compute_embroidery_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','embroidery')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.embroidery_qc_count = result.get(point.id, 0)

    def _compute_marker_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','marker')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.marker_qc_count = result.get(point.id, 0)

    def _compute_lay_spreading_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','lay_spreading')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.lay_spreading_qc_count = result.get(point.id, 0)

    def _compute_fusing_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','fusing')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.fusing_qc_count = result.get(point.id, 0)

# QC : 3
    def _compute_new_order(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','new_order')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.new_order_count= result.get(point.id, 0)

    def _compute_inline_report(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids), ('type', '=', 'inline_report')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.inline_report_count = result.get(point.id, 0)

    def _compute_audit_report(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids), ('type', '=', 'audit_report')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.audit_report_count = result.get(point.id, 0)

    def _compute_daily_top_3_faults(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids), ('type', '=', 'daily_top_3_faults')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.daily_top_3_faults_count = result.get(point.id, 0)

    def _compute_full_body_measurement_stitching(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids), ('type', '=', 'full_body_measurement_stitching')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.full_body_measurement_stitching_count = result.get(point.id, 0)



# QC : 4

    def _compute_dry_wash_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','dry_wash')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.dry_wash_qc_count = result.get(point.id, 0)

    def _compute_wet_wash_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','wet_wash')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.wet_wash_qc_count = result.get(point.id, 0)

# QC : 5

    def _compute_button_and_rivets_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','button_and_rivets')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.button_and_rivets_qc_count = result.get(point.id, 0)

    def _compute_label_section_report_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','label_section_report')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.label_section_report_qc_count = result.get(point.id, 0)

    def _compute_pull_test_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','pull_test')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.pull_test_qc_count = result.get(point.id, 0)

# QC : 6

    def compute_accessories_inspection_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','accessories_inspection')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.accessories_inspection_qc_count = result.get(point.id, 0)

    def compute_daily_major_quality_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','daily_major_quality')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.daily_major_quality_qc_count = result.get(point.id, 0)

    def compute_full_body_measurement_report_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','full_body_measurement_report')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.full_body_measurement_report_qc_count = result.get(point.id, 0)

    def compute_mending_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','mending')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.mending_qc_count = result.get(point.id, 0)
# QC: 7
    def compute_final_qc_counts(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids), ('type', '=', 'final_qc')],
                                                          ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.final_qc_count = result.get(point.id, 0)

    def _compute_standard_deviation_and_average(self):
        # The variance and mean are computed by the Welford’s method and used the Bessel's
        # correction because are working on a sample.
        for point in self:
            if point.test_type != 'measure':
                point.average = 0
                point.standard_deviation = 0
                continue
            mean = 0.0
            s = 0.0
            n = 0
            for check in point.check_ids.filtered(lambda x: x.quality_state != 'none'):
                n += 1
                delta = check.measure - mean
                mean += delta / n
                delta2 = check.measure - mean
                s += delta * delta2

            if n > 1:
                point.average = mean
                point.standard_deviation = sqrt( s / ( n - 1))
            elif n == 1:
                point.average = mean
                point.standard_deviation = 0.0
            else:
                point.average = 0.0
                point.standard_deviation = 0.0

    def action_quality_check2(self):
        self.qcp_type = 'qc2'

    def action_quality_check3(self):
        qc2_dict = {}

        if self.q2pri == False:
            qc2_dict["printing"] = False
            if self.printing_qc_count > 0:
                qc2_dict["printing"] = True

        if self.q2cut == False:
            qc2_dict["cutting"] = False
            if self.cutting_inspection_count > 0:
                qc2_dict["cutting"] = True

        if self.q2emb == False:
            qc2_dict["embroidery"] = False
            if self.embroidery_qc_count > 0:
                qc2_dict["embroidery"] = True

        if self.q2mar == False:
            qc2_dict["marker"] = False
            if self.marker_qc_count > 0:
                qc2_dict["marker"] = True


        if self.q2lay == False:
            qc2_dict["lay_spreading"] = False
            if self.lay_spreading_qc_count > 0:
                qc2_dict["lay_spreading"] = True


        if self.q2fus == False:
            qc2_dict["fusing"] = False
            if self.fusing_qc_count > 0:
                qc2_dict["fusing"] = True

        if False in qc2_dict.values():
            raise UserError(_("Please Complete Cutting QC First Before proceed to Stitching QC !!"))
        else:
            self.qcp_type = 'qc3'



    def action_quality_check4(self):
        qc3_dict = {}

        if self.q3new == False:
            qc3_dict["new_order"] = False
            if self.new_order_count > 0:
                qc3_dict["new_order"] = True


        if self.q3inl == False:
            qc3_dict["inline_report"] = False
            if self.inline_report_count > 0:
                qc3_dict["inline_report"] = True


        if self.q3aud == False:
            qc3_dict["audit_report"] = False
            if self.audit_report_count > 0:
                qc3_dict["audit_report"] = True

        if self.q3dai == False:
            qc3_dict["daily_top_3_faults"] = False
            if self.daily_top_3_faults_count > 0:
                qc3_dict["daily_top_3_faults"] = True

        if self.q3ful == False:
            qc3_dict["full_body_measurement_stitching"] = False
            if self.full_body_measurement_stitching_count > 0:
                qc3_dict["full_body_measurement_stitching"] = True
        print(qc3_dict)
        if False in qc3_dict.values():
            raise UserError(_("Please Complete Stitching QC First Before proceed to Washing QC !!"))
        else:
            self.qcp_type = 'qc4'


    def action_quality_check5(self):
        qc4_dict = {}

        if self.q4dry == False:
            qc4_dict["dry_wash"] = False
            if self.dry_wash_qc_count > 0:
                qc4_dict["dry_wash"] = True


        if self.q4wet == False:
            qc4_dict["wet_wash"] = False
            if self.wet_wash_qc_count > 0:
                qc4_dict["wet_wash"] = True


        if False in qc4_dict.values():
            raise UserError(_("Please Complete Washing QC First Before proceed to Pre Finishing QC !!"))
        else:
            self.qcp_type = 'qc5'



    def action_quality_check6(self):
        qc5_dict = {}
        if self.q5but == False:
            qc5_dict["button_and_rivets"] = False
            if self.button_and_rivets_qc_count > 0:
                qc5_dict["button_and_rivets"] = True

        if self.q5lab == False:
            qc5_dict["label_section_report"] = False
            if self.label_section_report_qc_count > 0:
                qc5_dict["label_section_report"] = True

        if self.q5pul == False:
            qc5_dict["pull_test"] = False
            if self.pull_test_qc_count > 0:
                qc5_dict["pull_test"] = True

        if False in qc5_dict.values():
            raise UserError(_("Please Complete Pre Finishing QC First Before proceed to Finishing QC !!"))
        else:
            self.qcp_type = 'qc6'



    def action_quality_check7(self):
        qc6_dict= {}
        if self.q6acc == False:
            qc6_dict["accessories_inspection"] = False
            if self.accessories_inspection_qc_count > 0:
                qc6_dict["accessories_inspection"] = True

        if self.q6dai == False:
            qc6_dict["daily_major_quality"] = False
            if self.daily_major_quality_qc_count > 0:
                qc6_dict["daily_major_quality"] = True

        if self.q6ful == False:
            qc6_dict["full_body_measurement_report"] = False
            if self.full_body_measurement_report_qc_count > 0:
                qc6_dict["full_body_measurement_report"] = True

        if self.q6men == False:
            qc6_dict["mending"] = False
            if self.mending_qc_count > 0:
                qc6_dict["mending"] = True

        if False in qc6_dict.values():
            raise UserError(_("Please Complete Finishing QC First Before proceed to Final QC!!"))
        else:
            self.qcp_type = 'qc7'



    @api.onchange('norm')
    def onchange_norm(self):
        if self.tolerance_max == 0.0:
            self.tolerance_max = self.norm

    def check_execute_now(self):
        self.ensure_one()
        if self.measure_frequency_type == 'all':
            return True
        elif self.measure_frequency_type == 'random':
            return (random.random() < self.measure_frequency_value / 100.0)
        elif self.measure_frequency_type == 'periodical':
            delta = False
            if self.measure_frequency_unit == 'day':
                delta = relativedelta(days=self.measure_frequency_unit_value)
            elif self.measure_frequency_unit == 'week':
                delta = relativedelta(weeks=self.measure_frequency_unit_value)
            elif self.measure_frequency_unit == 'month':
                delta = relativedelta(months=self.measure_frequency_unit_value)
            date_previous = datetime.today() - delta
            checks = self.env['quality.check'].search([
                ('point_id', '=', self.id),
                ('create_date', '>=', date_previous.strftime(DEFAULT_SERVER_DATETIME_FORMAT))], limit=1)
            return not(bool(checks))
        return super(QualityPoint, self).check_execute_now()

    def _get_type_default_domain(self):
        domain = super(QualityPoint, self)._get_type_default_domain()
        domain.append(('technical_name', '=', 'passfail'))
        return domain

    def action_see_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main').read()[0]
        action['domain'] = [('point_id', '=', self.id)]
        action['context'] = {
            'default_company_id': self.company_id.id,
            'qcp_type': self.qcp_type,
            'default_point_id': self.id
        }
        return action


# QC 2 : Actions

    def action_printing_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_printing_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_printing_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_printing_check_view_form').id, 'form')]

        action['domain'] = [('point_id', '=', self.id),('type','=','printing')]
        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'printing',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action



    def action_cutting_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.quality_check_action_main_cutting_extension').read()[0]

        action['views'] = [(self.env.ref('quality_control.quality_check_cutting_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_cutting_check_view_form').id, 'form')]

        action['domain'] = [('point_id', '=', self.id),('type','=','cutting')]

        action['context'] = {
            'default_team_id': self.team_id.id,
            'default_title': self.title,
            'default_type': 'cutting',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_order_quantity': self.order_quantity,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            # 'default_qcp_type': self.qcp_type,
            'default_product_id': self.product_id.id,
            'default_company_id': self.company_id.id,

        }
        return action

    def action_embroidery_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.quality_check_action_main_embroidery_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id),('type','=','embroidery')]

        action['views'] = [(self.env.ref('quality_control.quality_check_embroidery_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_embroidery_check_view_form').id, 'form')]

        action['context'] = {
            'default_title': self.title,
            'default_team_id': self.team_id.id,
            'default_company_id': self.company_id.id,
            # 'default_qcp_type': self.qcp_type,
            'default_type': 'embroidery',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_marker_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.quality_check_action_main_marker_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id),('type','=','marker')]

        action['views'] = [(self.env.ref('quality_control.quality_check_marker_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_marker_check_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'marker',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_lay_spreading_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.quality_check_action_main_lay_spreading_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id),('type','=','lay_spreading')]

        action['views'] = [(self.env.ref('quality_control.quality_check_lay_spreading_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_lay_spreading_check_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'lay_spreading',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action


    def action_fusing_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.quality_check_action_main_fusing_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id),('type','=','fusing')]

        action['views'] = [(self.env.ref('quality_control.quality_check_fusing_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_fusing_check_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'fusing',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action
# QC 3 : Actions

    def action_new_order_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_new_order_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_new_order_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_new_order_view_form').id, 'form')]

        action['domain'] = [('point_id', '=', self.id),('type','=','new_order')]
        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'new_order',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_inline_report_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_inline_report_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_inline_report_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_inline_report_view_form').id, 'form')]

        action['domain'] = [('point_id', '=', self.id),('type','=','inline_report')]
        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'inline_report',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_audit_report_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_audit_report_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_audit_report_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_audit_report_view_form').id, 'form')]

        action['domain'] = [('point_id', '=', self.id),('type','=','audit_report')]
        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'audit_report',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_daily_top_3_faults_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_daily_top_3_faults_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_daily_top_3_faults_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_daily_top_3_faults_view_form').id, 'form')]

        action['domain'] = [('point_id', '=', self.id),('type','=','daily_top_3_faults')]
        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'daily_top_3_faults',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_full_body_measurement_stitching_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main_full_body_measurement_stitching_extension').read()[0]
        action['views'] = [(self.env.ref('quality_control.quality_check_full_body_measurement_stitching_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_full_body_measurement_stitching_view_form').id, 'form')]

        action['domain'] = [('point_id', '=', self.id),('type','=','full_body_measurement_stitching')]
        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'full_body_measurement_stitching',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

# QC 4: Actions

    def action_dry_wash_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_quality_check_dry_wash_qc_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id),('type','=','dry_wash')]

        action['views'] = [(self.env.ref('quality_control.quality_check_dry_wash_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_dry_wash_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'dry_wash',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action



    def action_wet_wash_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_quality_check_wet_wash_qc_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id),('type','=','wet_wash')]

        action['views'] = [(self.env.ref('quality_control.quality_check_wet_wash_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_wet_wash_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'wet_wash',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action



# QC 5: Actions

    def action_button_and_rivets_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_button_and_rivets_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id),('type','=','button_and_rivets')]

        action['views'] = [(self.env.ref('quality_control.quality_check_button_and_rivets_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_button_and_rivets_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'button_and_rivets',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_label_section_report_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_label_section_report_extension').read()[0]
        # action['name'] = 'Label Section Report'
        # print("action.name",action['name'], "\n",action)
        # action['name'] = _('Label Section Report')
        action['name'] = 'Label Section Report'
        action['domain'] = [('point_id', '=', self.id),('type','=','label_section_report')]

        action['views'] = [(self.env.ref('quality_control.quality_check_label_section_report_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_label_section_report_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'label_section_report',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_pull_test_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_pull_test_extension').read()[0]
        # action['name'] = 'Label Section Report'
        # print("action.name",action['name'], "\n",action)
        # action['name'] = _('Label Section Report')
        action['name'] = 'Pull Test'
        action['domain'] = [('point_id', '=', self.id),('type','=','pull_test')]

        action['views'] = [(self.env.ref('quality_control.quality_check_pull_test_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_pull_test_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'pull_test',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action


# QC 6: Actions

    def action_accessories_inspection_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_accessories_inspection_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id), ('type', '=', 'accessories_inspection')]

        action['views'] = [(self.env.ref('quality_control.quality_check_accessories_inspection_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_accessories_inspection_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'accessories_inspection',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_daily_major_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_daily_major_quality_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id), ('type', '=', 'daily_major_quality')]

        action['views'] = [(self.env.ref('quality_control.quality_check_daily_major_quality_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_daily_major_quality_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'daily_major_quality',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_full_body_measurement_report_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_full_body_measurement_report_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id), ('type', '=', 'full_body_measurement_report')]

        action['views'] = [(self.env.ref('quality_control.quality_check_full_body_measurement_report_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_full_body_measurement_report_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'full_body_measurement_report',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

    def action_mending_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_mending_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id), ('type', '=', 'mending')]

        action['views'] = [(self.env.ref('quality_control.quality_check_mending_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_check_mending_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'mending',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action
# QC: 7

    def action_final_quality_checks(self):
        self.ensure_one()

        action = self.env.ref('quality_control.action_final_quality_checks_extension').read()[0]

        action['domain'] = [('point_id', '=', self.id), ('type', '=', 'final_qc')]

        action['views'] = [(self.env.ref('quality_control.final_quality_checks_view_tree').id, 'tree')
            , (self.env.ref('quality_control.final_quality_checks_view_form').id, 'form')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_qcp_type': self.qcp_type,
            'default_type': 'final_qc',
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action



    def action_see_spc_control(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_spc').read()[0]
        if self.test_type == 'measure':
            action['context'] = {'group_by': ['name', 'point_id'], 'graph_measure': ['measure'], 'graph_mode': 'line'}
        action['domain'] = [('point_id', '=', self.id), ('quality_state', '!=', 'none')]
        return action
