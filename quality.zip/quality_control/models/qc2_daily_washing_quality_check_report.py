# -*- coding: utf-8 -*-


from odoo import api, models, fields, _, SUPERUSER_ID
class QualityPoint(models.Model):
    _inherit = "quality.point"
    daily_washing_report_count = fields.Integer(compute="_compute_daily_washing_report_count")

    def _compute_daily_washing_report_count(self):
        check_data = self.env['quality.check'].read_group([('point_id', 'in', self.ids),('type','=','daily_washing_report')], ['point_id'], ['point_id'])
        result = dict((data['point_id'][0], data['point_id_count']) for data in check_data)
        for point in self:
            point.daily_washing_report_count = result.get(point.id, 0)
    def action_daily_washing_report(self):
        self.ensure_one()

        action = self.env.ref('quality_control.quality_check_action_main_daily_washing_extension').read()[0]

        action['views'] = [(self.env.ref('quality_control.quality_check_daily_washing_view_tree').id, 'tree')
            , (self.env.ref('quality_control.quality_daily_washing_check_view_form').id, 'form')]

        action['domain'] = [('point_id', '=', self.id),('type','=','daily_washing_report')]

        action['context'] = {
            'default_company_id': self.company_id.id,
            'default_type': 'daily_washing_report',
            'default_qcp_type': self.qcp_type,
            'default_point_id': self.id,
            'default_order_no': self.order_id,
            'default_partner_id': self.partner_id.id,
            'default_sample_id': self.sample_id.id,
            'default_order_quantity': self.order_quantity,
            'default_product_id': self.product_id.id,
        }
        return action

class QualityCheckdailywashingreport(models.Model):
    _inherit = "quality.check"

    daily_washing_line_ids = fields.One2many('quality.check.daily_washing_qc_report', 'qc_id')
    shift = fields.Char()
    quality_controler = fields.Char()
    summery = fields.Text(string="Summary")
    # total_checked_pcs  # repeat
    total_ok_pcs = fields.Integer()
    # total_fault #repeat
    # dhu
    # quality_state
    quality_dm = fields.Many2one('res.users')
    product_manager = fields.Many2one('res.users')
    quality_manager = fields.Many2one('res.users')
    product_incharge = fields.Many2one('res.users')




class QualityCheck_DailyWashingQCReportline(models.Model):
    _name = "quality.check.daily_washing_qc_report"
    qc_id = fields.Many2one("quality.check")
    card_no = fields.Char()
    brand = fields.Char()
    wo = fields.Char("WO#")
    style = fields.Char()
    check_qty = fields.Char()
    ok_qty = fields.Char()
    light_shade = fields.Char()
    dark_shade = fields.Char()
    less_spray = fields.Char()
    high_spray = fields.Char()
    stain = fields.Char()
    washing_cracks = fields.Char()
    blue_shade = fields.Char()
    greener_shade = fields.Char()
    spot = fields.Char()
    lv = fields.Char("L/V")
    damage = fields.Char()
    other = fields.Char()
    total_falt = fields.Char()
