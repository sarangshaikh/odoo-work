# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from math import sqrt
from dateutil.relativedelta import relativedelta
from datetime import datetime
import random

from odoo import api, models, fields, _, SUPERUSER_ID
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT


class QualityCheck(models.Model):
    _inherit = "quality.check"

    # -----------------------------------------------------------------------------
    _rec_name = "title"
    title = fields.Char()
# Custom Changes
    qcp_type = fields.Selection([
        # ('qc1', 'Quality Check 1'),
        ('qc2', 'Cutting QC'),
        ('qc3', 'Stitching QC'),
        ('qc4', 'Washing QC'),
        ('qc5', 'Pre Finishing QC'),
        ('qc6', 'Finishing QC'),
        ('qc7', 'Final QC')], string="QCP Type", default='qc2',copy=False)


    type = fields.Selection([
        ('sampling_button_and_rivets', 'Sampling Button & Rivets'),
        ('sampling_label_section_report', 'Sampling Label Section Report'),
        ('sampling_pull_test', 'Sampling Pull Test'),
        ('sampling_accessories_inspection', 'Sampling Accessories Inspection'),
        ('sampling_daily_major_quality', 'Sampling Daily Major Quality'),
        ('sampling_full_body_measurement_report', 'Sampling Full Body Measurement Report'),
        ('sampling_mending', 'Sampling Mending'),
        ('sampling_final_qc', 'Sampling Final Quality Check'),
        ('sampling_audit_report', 'Sampling Audit_report'),
        ('sampling_daily_top_3_faults', 'Sampling Daily Top 3 Faults'),
        ('sampling_full_body_measurement_stitching', 'Sampling Full body measurement stitching'),
        ('sampling_inline', 'Sampling Inline'),
        ('sampling_printing', 'Sampling Printing'),
        ('sampling_cutting_inspection', 'Sampling Cutting Inspection'),
        ('sampling_embroidery', 'Sampling Embroidery'),
        ('sampling_marker', 'Sampling Marker'),
        ('sampling_lay_spreading', 'Sampling Lay Spreading'),
        ('sampling_fusing', 'Sampling Fusing'),
        ('sampling_new_order', 'Sampling New Order'),
        ('sampling_dry_wash', 'Sampling Dry Wash'),
        ('sampling_wet_wash', 'Sampling Wet Wash'),
        ('printing', 'Printing'),
        ('cutting', 'Cutting'),
        ('embroidery', 'Embroidery'),
        ('marker', 'Marker'),
        ('lay_spreading', 'Lay Spreading'),
        ('fusing', 'Fusing'),
        ('dry_wash', 'Dry Wash'),
        ('wet_wash', 'Wet Wash'),
        ('button_and_rivets', 'Button & Rivets'),
        ('label_section_report', 'Label Section Report'),
        ('pull_test', 'Pull Test'),
        ('accessories_inspection', 'Accessories Inspection'),
        ('daily_major_quality', 'Daily Major Quality'),
        ('full_body_measurement_report', 'Full Body Measurement Report'),
        ('new_order','New order'),
        ('inline_report', 'Inline Report'),
        ('audit_report', 'Audit_report'),
        ('daily_top_3_faults', 'Daily Top 3 Faults'),
        ('full_body_measurement_stitching', 'Full body measurement stitching'),
        ('mending', 'Mending'),
        ('final_qc', 'Final Quality Check'),
        ('daily_washing_report', 'Daily Washing Report'),
    ],)
#QC : 3
    # new order checklist

    # < field
    # name = "order_no" / >
    # < field
    # name = "sample_id"
    # options = "{'no_create': True}"
    # readonly = "1" / >
    # < field
    # name = "partner_id" / >
    # < field
    # name = "order_quantity" / >
    # < field
    # name = "product_id" / >

    order_qty = fields.Integer()
    order_no = fields.Char()
    order_quantity = fields.Float()
    sample_id = fields.Many2one('qc.sample',domain=[('state','=','approve')])

    cutting_by = fields.Many2one('res.users')

    operation_stitching = fields.Char()
    # customer = fields.Char()
    corrective_action = fields.Char()
    style = fields.Char()
    order_induction_date = fields.Char()
    line_no = fields.Char()
    part_type = fields.Selection([('small part', 'Small Part'),('front', 'Front'),('back', 'Back'),('assembly', 'Assembly')])
    thread_checkpoint = fields.Char()
    Ngauge_checkpoint = fields.Char()
    SPI_checkpoint = fields.Char()
    placements_checkpoint = fields.Char()
    specs_checkpoint = fields.Char()
    workmanship_checkpoint = fields.Char()

    # inline_report
    # order_no = fields.Char() #repeat
    # operation_stitching = fields.Char() #repeat
    # part_type = fields.Selection([('small part', 'Small Part'),('front', 'Front'),('back', 'Back'),('assembly')]) #repeat
    # order_qty = fields.Integer() #repeat
    date = fields.Date(default=fields.Date.today)
    shrinkage = fields.Char()
    MH_no = fields.Char()
    thread = fields.Char()
    specs = fields.Char()
    gauge = fields.Char()
    placement = fields.Char()
    UBTs = fields.Char()
    styling = fields.Char()
    workmenship = fields.Char()
    labels = fields.Char()
    needle_operation = fields.Selection([('back rise safety & top stitch feedo', 'Back rise safety & Top stitch feedo'),('crotch attach','Crotch Attach'),('side seam safety','Side seam safety'),('inseam safety', 'Inseam safety')])
    shift_start = fields.Char()
    shift_mid = fields.Char()
    shift_end = fields.Char()
    needle_type = fields.Char()
    okay = fields.Boolean()
    machine_rpm_required = fields.Char()
    machine_rpm_okay = fields.Boolean()

    # Audit Report
    # order_no # repeat
    # customer # repeat
    # style # repeat
    audit_part_type = fields.Selection([('small part', 'Small part'), ('front', 'Front'), ('back', 'Back'), ('waist band', 'Waist band'),('end line inspection', 'End line inspection')])
    audit_date = fields.Date()
    # line_no # repeat
    section = fields.Char()
    defects_stitching = fields.Char()
    cut_no = fields.Integer()
    size = fields.Float()
    stitching_operation = fields.Char()
    total_defects = fields.Integer()
    bundle_status = fields.Selection([('yes','Yes'),('no', 'No')])
    dhu = fields.Char()
    total_checked_pcs = fields.Integer()
    total_fault = fields.Char()
    remarks = fields.Text()
    cutting_defect1= fields.Text()
    cutting_defect2= fields.Text()
    cutting_defect3= fields.Text()
    production_incharge = fields.Char()
    quality_incharge = fields.Char()
    qc = fields.Char(string="QC")
    checked_by = fields.Char()
    quality_am = fields.Char()

    cu = fields.Text()
    nu = fields.Text()
    nm = fields.Text()
    fp = fields.Text()
    sp = fields.Text()
    np = fields.Text()



    # Daily top 3 faults
    # line_no #repeat
    # date # repeat
    defect_no = fields.Integer()
    defect_name = fields.Char()
    opt_name = fields.Char()
    noq = fields.Char()
    reject_qty = fields.Float()
    # total_checked_pcs
    # dhu

    # full body measurement stitching
    # order_no # repeat
    # customer
    # style
    # date
    measurement_taken = fields.Char()
    size_description = fields.Char()
    tolerance = fields.Char()
    required_size = fields.Float()
    actual_size = fields.Float()


# QC : 2
    # printing
    # total_checked_pcs = fields.Integer() # repeat
    # size = fields.Float() # repeat
    faults = fields.Integer()
    # order_no = fields.Char() #repeat
    bd_no = fields.Char()
    # total_fault = fields.Char() #repeat
    # dhu = fields.Char() # repeat
    total_production = fields.Char()

    # Cutting

    # total_defects = fields.Integer() # repeat
    # total_checked_pcs = fields.Integer() # again
    total_cutting_qty = fields.Integer()
    no_of_cuts = fields.One2many('cuts.info', 'cuts_id')
    part_name = fields.Char()
    fault = fields.Char()
    # order   # Repeat
    # DHU     # Repeat

    # Embriodery
    # bd_no = fields.Integer() # Repeat
    # size = fields.Float() # Repeat
    no_cuts = fields.Integer()
    # placement = fields.Char() # Repeat
    # total_defects = fields.Integer() # Repeat
    # total_checked_pcs # Repeat
    # Order # Repeat
    # DHU # repeat
    # faults = fields.Integer() # repeat

    # Marker QC
    placement_ids = fields.One2many('qc.placement', 'placement_id')
    inseam = fields.Char()
    band = fields.Char()
    loops = fields.Char()
    # faults = fields.Char() # Repeat
    # size = fields.Char()# Repeat
    # order_no = = fields.Char()# Repeat
    fabric = fields.Char()
    width = fields.Char()
    length = fields.Char()
    marker_name = fields.Char()
    marker_qty = fields.Char()
    # shrinkage = fields.Char() # repeat

    # Lay Spreading
    # fabric # Repeat
    shade = fields.Char()
    # shrinkage #repeat
    roll_no = fields.Char()
    total_meters = fields.Char()
    spread_time_limit = fields.Char()
    unroll_time_limit = fields.Char()
    # no_cuts = fields.Char() #repeat

    # Fusing QC

    temp_requirement = fields.Char()
    actual_temprature = fields.Char()
    audit_ok = fields.Boolean()
    # order_no  = fields.Char() # repeat
    # placement  = fields.Char() # repeat
    # total_checked_pcs  = fields.Char() # Repear
    # dhu  = fields.Char() # repeat
    # faults  = fields.Char() # repeat
    peeling_strength = fields.Char()
    maching_type = fields.Char()

    # NEW fields
    # CUTT
    work_order_no = fields.Char() # cutt
    # style = fields.Char()# cutt repeat
    # no_cuts = fields.Char()# cutt repeat
    partner_id = fields.Many2one('res.partner', string="Customer")
    # fabric = fields.Char() repeat
    user_id = fields.Many2one('res.users',)# Cutting by
    ordered_qty = fields.Float()
    # shrinkage=fields.Char() # repeat
    no_of_piles = fields.Integer()
    # date = fields.Date() # repeat

    front_panel = fields.Selection([('right', 'Right'),('left', 'Left')])
    back_panel = fields.Selection([('right', 'Right'),('left', 'Left')])
    back_yoke = fields.Selection([('right', 'Right'),('left', 'Left')])
    front_facing = fields.Selection([('right', 'Right'),('left', 'Left')])
    back_pocket = fields.Selection([('right', 'Right'),('left', 'Left')])
    ticket_pocket = fields.Boolean()
    sf = fields.Char()
    df = fields.Char()
    l = fields.Char()

    flap = fields.Selection([('right', 'Right'),('left', 'Left')])
    knee_pkt = fields.Selection([('right', 'Right'),('left', 'Left')])

    total_cuttings = fields.Char()


    total_frontpanel_r = fields.Integer(string=" Front Panel (R)",compute="_compute_frontpanel")
    total_frontpanel_l = fields.Integer(string="Front Panel (L)",compute="_compute_frontpanel")

    total_backpanel_r = fields.Integer(string="Back Panel (R)",compute="_compute_backpanel")
    total_backpanel_l = fields.Integer(string="Back Panel (L)",compute="_compute_backpanel")

    total_backyoke_r = fields.Integer(string="Back Yoke (R)",compute="_compute_backyoke")
    total_backyoke_l = fields.Integer(string="Back Yoke (L)",compute="_compute_backyoke")

    total_backfacing_r = fields.Integer(string="Back Facing (R)",compute="_compute_backfacing")
    total_backfacing_l = fields.Integer(string="Back Facing (L)",compute="_compute_backfacing")

    total_backpocket_r = fields.Integer(string="Back Pocket (R)",compute="_compute_backpocket")
    total_backpocket_l = fields.Integer(string="Back Pocket (L)",compute="_compute_backpocket")

    total_flap_r = fields.Integer(string="Flap (R)",compute="_compute_flap")
    total_flap_l = fields.Integer(string="Flap (L)",compute="_compute_flap")

    total_kneepkt_r = fields.Integer(string="Knee PKT (R)",compute="_compute_kneepkt")
    total_kneepkt_l = fields.Integer(string="Knee PKT (L)",compute="_compute_kneepkt")


    @api.depends('no_of_cuts.frontpanel_r','no_of_cuts.frontpanel_l')
    def _compute_frontpanel(self):
        for rec in self:
            rec.total_frontpanel_r = 0
            rec.total_frontpanel_l = 0
            if self.no_of_cuts.ids:
                for line in self.no_of_cuts:
                    if line.frontpanel_r == True:
                        rec.total_frontpanel_r += 1
                    if line.frontpanel_l == True:
                        rec.total_frontpanel_l += 1

    @api.depends('no_of_cuts.backpanel_r','no_of_cuts.backpanel_l')
    def _compute_backpanel(self):
        for rec in self:
            rec.total_backpanel_r = 0
            rec.total_backpanel_l = 0
            if self.no_of_cuts.ids:
                for line in self.no_of_cuts:
                    if line.backpanel_r == True:
                        rec.total_backpanel_r += 1
                    if line.backpanel_l == True:
                        rec.total_backpanel_l += 1



    @api.depends('no_of_cuts.backyoke_r','no_of_cuts.backyoke_l')
    def _compute_backyoke(self):
        for rec in self:
            rec.total_backyoke_r = 0
            rec.total_backyoke_l = 0
            if self.no_of_cuts.ids:
                for line in self.no_of_cuts:
                    if line.backyoke_r == True:
                        rec.total_backyoke_r += 1
                    if line.backyoke_l == True:
                        rec.total_backyoke_l += 1


    @api.depends('no_of_cuts.backfacing_r','no_of_cuts.backfacing_l')
    def _compute_backfacing(self):
        for rec in self:
            rec.total_backfacing_r = 0
            rec.total_backfacing_l = 0
            if self.no_of_cuts.ids:
                for line in self.no_of_cuts:
                    if line.backfacing_r == True:
                        rec.total_backfacing_r += 1
                    if line.backfacing_l == True:
                        rec.total_backfacing_l += 1

    @api.depends('no_of_cuts.backpocket_r','no_of_cuts.backpocket_l')
    def _compute_backpocket(self):
        for rec in self:
            rec.total_backpocket_r = 0
            rec.total_backpocket_l = 0
            if self.no_of_cuts.ids:
                for line in self.no_of_cuts:
                    if line.backpocket_r == True:
                        rec.total_backpocket_r += 1
                    if line.backpocket_l == True:
                        rec.total_backpocket_l += 1

    @api.depends('no_of_cuts.flap_r','no_of_cuts.flap_l')
    def _compute_flap(self):
        for rec in self:
            rec.total_flap_r = 0
            rec.total_flap_l = 0
            if self.no_of_cuts.ids:
                for line in self.no_of_cuts:
                    if line.flap_r == True:
                        rec.total_flap_r += 1
                    if line.flap_l == True:
                        rec.total_flap_l += 1

    @api.depends('no_of_cuts.kneepkt_r','no_of_cuts.kneepkt_l')
    def _compute_kneepkt(self):
        for rec in self:
            rec.total_kneepkt_r = 0
            rec.total_kneepkt_l = 0
            if self.no_of_cuts.ids:
                for line in self.no_of_cuts:
                    if line.kneepkt_r == True:
                        rec.total_kneepkt_r += 1
                    if line.kneepkt_l == True:
                        rec.total_kneepkt_l += 1


    # Embroidery

    # partner_id  # Customer repeat
    # Date
    bundle_quantity = fields.Char()
    embriodery_part = fields.Char()
    faults_name = fields.Selection([('placement', 'Placement_out'),('skip_lose', 'Skip/Lose'),('broken_stich', 'Broken Stich'),('uncut_thread', 'Uncut Thread')])

    # placement_out = fields.Char()
    # skip_lose = fields.Char("Skip/Lose")
    # broken_stich = fields.Char()
    # uncut_thread = fields.Char()
    # remarks = fields.Char()
    # total_production # repeat
    # user_id = fields.Many2one('res.users',)# Checked by

    # Fusing

    # partner_id # repeat
    #     ordered_qty = fields.Float()  #QTY # repeat
    fusing_type_and_color = fields.Char()
    attachment = fields.Binary(attachment=True)
    # date = fields.Date() # repeat

    #Marker

    # order_no = fields.Char("New WO")
    repeat_wo = fields.Char("New WO")
    # partner_id = fields Customer
    total_qty = fields.Float()
    # marker_name = fields.Char() Repeat #  Marker Name
    # user_id = fields #  Checked by  Marker Name
    # date = fields # date

    #Lay Spreading

    # order_no = fields.Char("WO #")
    # partner_id
    marker_shrinking = fields.Char()
    # no_cuts
    # shade
    # roll_no
    unroll_date = fields.Char()
    spreading_date = fields.Date()
    marker_length =  fields.Float()
    marker_width =  fields.Float()
    lay_height =  fields.Float()
    # total_qty total_piece
    # style
    fabric_quality = fields.Char()
    marker_ratio =  fields.Float()
    # no_of_piles
    # shrinkage
    # total_meters
    # unroll_time_limit
    # spread_time_limit
    no_of_layers = fields.Char()
    # partner_id checked_by

    #Printing

    # partner_id
    # date
    # fault name
    printing_part = fields.Char()
    # user_id

# QC : 4
    # Dry Wash QC
    # order_no # wo no Repeat
    #date repeat
    #partner_id
    wsl_ids = fields.One2many('wsl.options','qc_id')

    # Wet Wash QC
    # order_no
    wash_code = fields.Char()
    actual_wash_time = fields.Char()
    # total_production # repeat
    # faults_name # repeat
    # partner_id repeat
    # date  Repeat
    req_wash_time = fields.Float() # Time
    # dhu repeat
    reinforcement = fields.Boolean()


# QC 5
    #Buttons and rivets QC
    # order_no
    # total_qty
    # fault
    rejected_pieces = fields.Float()
    # date
    f_qty = fields.Float()
    action_taken = fields.Text()
    # total_checked_pcs
    checked_gmt = fields.Char()
    # style
    color = fields.Char()
    # dhu

    #label section report

    # order_no
    # total_qty # pcs
    label_type = fields.Char()
    # dhu
    # partner_id
    # date
    # placement
    # total_checked_pcs
    # checked_gmt
    # f_qty

    # Pull Test

    # order_no
    # ordered_qty
    # style
    # color
    strength_applied = fields.Char()
    time = fields.Float() # time
    status = fields.Char() # i think repeat i can be pass or fail
    # date
    # partner_id
    po_number = fields.Char()
    # size  # garment size
    # total_qty #  No of pieces
    # action_taken
# QC : 6
#     Daily Major Report
    # order_no
    qty = fields.Float(string="Quantity")
    # pcs_checked = fields.Integer()
    # dhu
    # date =
    operator_code = fields.Char()
    # faults = fields.Integer()
    # total_fault

    # Accessories Inspection
    # order_no
    cuts_qty = fields.Float()
    # dhu
    po_qty = fields.Float()
    # placement =
    # total_fault
    #faults
    #date

# Mending QC
    # order_no
    # status
    # date
    # rejected_pieces
    total_mended_item = fields.Integer()
    # style =
    operation = fields.Char()

# Full Body Measurement
    # order_no
    # measurement_taken = fields.Char()
    # size = fields.Integer()
    wash_no = fields.Integer()
    # dhu
    # style
    # total_checked_pcs
    # rejected_pieces
    # tolerance = fields.Char()




# QC : 7
    # order_no
    # total_production = fields.char()
    # partner_id = fields.Many2one('res.partner',string="Customer")
    rejected_qty = fields.Float()
    lead_time = fields.Date()
    approved_qty =   fields.Float()
    total_lead_time = fields.Date()
    order_approved_date = fields.Date()
    lost_qty_per_dept= fields.Float()
    # -----------------------------------------------------------------------------
    failure_message = fields.Html(related='point_id.failure_message', readonly=True)
    measure = fields.Float('Measure', default=0.0, digits='Quality Tests', tracking=True)
    measure_success = fields.Selection([
        ('none', 'No measure'),
        ('pass', 'Pass'),
        ('fail', 'Fail')], string="Measure Success", compute="_compute_measure_success",
        readonly=True, store=True)
    tolerance_min = fields.Float('Min Tolerance', related='point_id.tolerance_min', readonly=True)
    tolerance_max = fields.Float('Max Tolerance', related='point_id.tolerance_max', readonly=True)
    warning_message = fields.Text(compute='_compute_warning_message')
    norm_unit = fields.Char(related='point_id.norm_unit', readonly=True)














    @api.depends('measure_success')
    def _compute_warning_message(self):
        for rec in self:
            if rec.measure_success == 'fail':
                rec.warning_message = _('You measured %.2f %s and it should be between %.2f and %.2f %s.') % (
                    rec.measure, rec.norm_unit, rec.point_id.tolerance_min,
                    rec.point_id.tolerance_max, rec.norm_unit
                )
            else:
                rec.warning_message = ''

    @api.depends('measure')
    def _compute_measure_success(self):
        for rec in self:
            if rec.point_id.test_type == 'passfail':
                rec.measure_success = 'none'
            else:
                if rec.measure < rec.point_id.tolerance_min or rec.measure > rec.point_id.tolerance_max:
                    rec.measure_success = 'fail'
                else:
                    rec.measure_success = 'pass'

    # Add picture dependency
    @api.depends('picture')
    def _compute_result(self):
        super(QualityCheck, self)._compute_result()

    def _get_check_result(self):
        if self.test_type == 'picture' and self.picture:
            return _('Picture Uploaded')
        else:
            return super(QualityCheck, self)._get_check_result()

    def do_measure(self):
        self.ensure_one()
        if self.measure < self.point_id.tolerance_min or self.measure > self.point_id.tolerance_max:
            return self.do_fail()
        else:
            return self.do_pass()

    def correct_measure(self):
        self.ensure_one()
        return {
            'name': _('Quality Checks'),
            'type': 'ir.actions.act_window',
            'res_model': 'quality.check',
            'view_mode': 'form',
            'view_id': self.env.ref('quality_control.quality_check_view_form_small').id,
            'target': 'new',
            'res_id': self.id,
            'context': self.env.context,
        }

    def do_alert(self):
        self.ensure_one()
        alert = self.env['quality.alert'].create({
            'check_id': self.id,
            'product_id': self.product_id.id,
            'product_tmpl_id': self.product_id.product_tmpl_id.id,
            'lot_id': self.lot_id.id,
            'user_id': self.user_id.id,
            'team_id': self.team_id.id,
            'company_id': self.company_id.id
        })
        return {
            'name': _('Quality Alert'),
            'type': 'ir.actions.act_window',
            'res_model': 'quality.alert',
            'views': [(self.env.ref('quality_control.quality_alert_view_form').id, 'form')],
            'res_id': alert.id,
            'context': {'default_check_id': self.id},
        }

    def action_see_alerts(self):
        self.ensure_one()
        if len(self.alert_ids) == 1:
            return {
                'name': _('Quality Alert'),
                'type': 'ir.actions.act_window',
                'res_model': 'quality.alert',
                'views': [(self.env.ref('quality_control.quality_alert_view_form').id, 'form')],
                'res_id': self.alert_ids.ids[0],
                'context': {'default_check_id': self.id},
            }
        else:
            action = self.env.ref('quality_control.quality_alert_action_check').read()[0]
            action['domain'] = [('id', 'in', self.alert_ids.ids)]
            action['context'] = dict(self._context, default_check_id=self.id)
            return action

    def redirect_after_pass_fail(self):
        check = self[0]
        if check.quality_state == 'fail' and check.test_type in ['passfail', 'measure']:
            return self.show_failure_message()
        if check.picking_id:
            checks = self.picking_id.check_ids.filtered(lambda x: x.quality_state == 'none')
            if checks:
                action = self.env.ref('quality_control.quality_check_action_small').read()[0]
                action['res_id'] = checks.ids[0]
                return action
        return super(QualityCheck, self).redirect_after_pass_fail()

    def redirect_after_failure(self):
        check = self[0]
        if check.picking_id:
            checks = self.picking_id.check_ids.filtered(lambda x: x.quality_state == 'none')
            if checks:
                action = self.env.ref('quality_control.quality_check_action_small').read()[0]
                action['res_id'] = checks.ids[0]
                return action
        return super(QualityCheck, self).redirect_after_pass_fail()

    def show_failure_message(self):
        return {
            'name': _('Quality Check Failed'),
            'type': 'ir.actions.act_window',
            'res_model': 'quality.check',
            'view_mode': 'form',
            'view_id': self.env.ref('quality_control.quality_check_view_form_failure').id,
            'target': 'new',
            'res_id': self.id,
            'context': self.env.context,
        }
