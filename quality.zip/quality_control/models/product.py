# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from math import sqrt
from dateutil.relativedelta import relativedelta
from datetime import datetime
import random

from odoo import api, models, fields, _, SUPERUSER_ID
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT



class ProductTemplate(models.Model):
    _inherit = "product.template"

    quality_control_point_qty = fields.Integer(compute='_compute_quality_check_qty', groups='quality.group_quality_user')
    quality_pass_qty = fields.Integer(compute='_compute_quality_check_qty', groups='quality.group_quality_user')
    quality_fail_qty = fields.Integer(compute='_compute_quality_check_qty', groups='quality.group_quality_user')

    @api.depends('product_variant_ids')
    def _compute_quality_check_qty(self):
        self.quality_fail_qty = 0
        self.quality_pass_qty = 0
        self.quality_control_point_qty = 0

        for product_tmpl in self:
            quality_checks_by_state = self.env['quality.check'].read_group(
                [('product_id', 'in', product_tmpl.product_variant_ids.ids), ('company_id', '=', self.env.company.id)],
                ['product_id'],
                ['quality_state']
            )
            for checks_data in quality_checks_by_state:
                if checks_data['quality_state'] == 'fail':
                    product_tmpl.quality_fail_qty = checks_data['quality_state_count']
                elif checks_data['quality_state'] == 'pass':
                    product_tmpl.quality_pass_qty = checks_data['quality_state_count']
            product_tmpl.quality_control_point_qty = self.env['quality.point'].search_count([
                ('product_tmpl_id', '=', product_tmpl.id), ('company_id', '=', self.env.company.id)
            ])

    def action_see_quality_control_points(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_point_action').read()[0]
        action['context'] = dict(self.env.context)
        action['context'].update({
            'search_default_product_tmpl_id': self.id,
            'default_product_tmpl_id': self.id,
        })
        return action

    def action_see_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main').read()[0]
        action['context'] = dict(self.env.context, default_product_id=self.product_variant_id.id, create=False)
        return action


class ProductProduct(models.Model):
    _inherit = "product.product"

    quality_control_point_qty = fields.Integer(compute='_compute_quality_check_qty', groups='quality.group_quality_user')
    quality_pass_qty = fields.Integer(compute='_compute_quality_check_qty', groups='quality.group_quality_user')
    quality_fail_qty = fields.Integer(compute='_compute_quality_check_qty', groups='quality.group_quality_user')

    def _compute_quality_check_qty(self):
        self.quality_fail_qty = 0
        self.quality_pass_qty = 0
        self.quality_control_point_qty = 0
        for product in self:
            quality_checks_by_state = self.env['quality.check'].read_group(
                [('product_id', '=', product.id), ('company_id', '=', self.env.company.id)],
                ['product_id'],
                ['quality_state']
            )
            for checks_data in quality_checks_by_state:
                if checks_data['quality_state'] == 'fail':
                    product.quality_fail_qty = checks_data['quality_state_count']
                elif checks_data['quality_state'] == 'pass':
                    product.quality_pass_qty = checks_data['quality_state_count']
            product.quality_control_point_qty = self.env['quality.point'].search_count([
                ('product_id', '=', product.id), ('company_id', '=', self.env.company.id)
            ])

    def action_see_quality_control_points(self):
        self.ensure_one()
        action = self.product_tmpl_id.action_see_quality_control_points()
        return action

    def action_see_quality_checks(self):
        self.ensure_one()
        action = self.env.ref('quality_control.quality_check_action_main').read()[0]
        action['context'] = dict(self.env.context, default_product_id=self.id, create=False)
        return action
