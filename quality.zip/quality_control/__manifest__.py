# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Quality',
    'version': '1.0',
    'category': 'Manufacturing/Quality',
    'sequence': 50,
    'summary': 'Control the quality of your products',
    'website': '',
    'depends': ['quality'],
    'description': """
Quality Control
===============
* Define quality points that will generate quality checks on pickings,
  manufacturing orders or work orders (quality_mrp)
* Quality alerts can be created independently or related to quality checks
* Possibility to add a measure to the quality check with a min/max tolerance
* Define your stages for the quality alerts
""",
    'data': [
        'data/quality_control_data.xml',
        'views/quality_templates.xml',
        'security/ir.model.access.csv',
        'views/embroidery.xml',
        'views/quality_check_2.xml',
        'views/quality_check_3.xml',
        'views/quality_check_4.xml',
        'views/quality_check_5.xml',
        'views/quality_check_6.xml',
        'views/quality_check_7.xml',
        'views/quality_views.xml',
        'views/button_setup.xml',
        'wizard/revision_reason_view.xml',
        'views/sample.xml',
        'views/stock_picking_views.xml',
        'views/qc2_daily_washing_quality_check_report.xml',
    ],
    'demo': [
        'data/quality_control_demo.xml',
    ],
    'application': True,
    'license': 'OEEL-1',
}
